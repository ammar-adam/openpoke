# Routing challenge results

Candidate inclusion, dispatch identity, reviewed behavior, and publication content are separate measurements.

| Group / mode / scale / metadata | Complete | Not run | Incomplete | Operational error | Routing protocol / reviewed ASK or ANSWER | Unscored complete |
|---|---:|---:|---:|---:|---:|---:|
| validation / focus / 10000 / current_state / openai/gpt-6-luna | 14 | 0 | 0 | 0 | 8/11 | 3 |
| validation / retrieval / 10000 / current_state / openai/gpt-6-luna | 14 | 0 | 0 | 0 | 9/11 | 3 |

Repeats are listed by case in report.json. The attempt counts above are not independent case counts and do not imply a majority-vote product.

## Lookup and publication metadata

| Group / mode / scale / model | All targets initially present / observed | Correct automatic dispatch identities / observed | Matching publication source IDs / observed | Completed callbacks |
|---|---:|---:|---:|---:|
| validation / focus / 10000 / openai/gpt-6-luna | 9/9 | 9/10 | 7/7 | 7 |
| validation / retrieval / 10000 / openai/gpt-6-luna | 8/9 | 9/10 | 7/7 | 7 |

Source-ID agreement is metadata, not proof of correct displayed content. An unobserved or inapplicable metric stays 0/0, not perfect accuracy.

## Complete paired cases: routing protocol / reviewed ASK or ANSWER

- validation / 10000 / current_state: retrieval minus focus: +0.091; 11 complete scored cases, 3 excluded. This is descriptive, not statistical significance.

## Reviewed semantics and content

| Group / mode | Behavior reviewed / eligible | Publication reviewed / completed callbacks | Joint correct / evaluated | Structural joint failures | Joint reviewer labels: human / model-assisted |
|---|---:|---:|---:|---:|---:|
| validation / focus / 10000 / openai/gpt-6-luna | 0/14 | 0/7 | 0/1 | 1 | 0 / 0 |
| validation / retrieval / 10000 / openai/gpt-6-luna | 0/14 | 0/7 | 0/0 | 0 | 0 / 0 |

## Interpretation

- Candidate inclusion is not final worker selection or task completion.
- Operational errors, incomplete runs, and not-run records are shown separately; they have no quality score.
- Completed ASK/ANSWER responses need attributed review; an unexpected dispatch still fails.
- The routing protocol score includes matching worker dispatches, a finished IA loop, and no extra callback dispatch; it is broader than worker identity alone.
- Worker identity uses observed_dispatch_correct, with automatic_correct only as a compatibility fallback for old rows missing that field. Identity matching does not establish instruction fidelity or completed worker actions.
- Review metrics distinguish human from model-assisted judgments and retain unreviewed counts.
- Publication metrics use completed callbacks even if the later follow-up fails; joint scenario review requires the whole run to complete.
- Joint scenario review checks displayed content and response/instruction behavior; mocked workers cannot establish actual task completion.
- Response correctness reviews only the follow-up. A failed IA loop or an extra callback dispatch independently forces completed joint scenarios to fail, even when response and publication labels are true.
- Joint structural failures can be known before content review; unreviewed component counts remain separate and those failures are not presented as human judgments.
- Source-ID annotation agreement is metadata only, not proof that the right content was displayed.
- Repeated attempts remain grouped by case; no majority-vote policy or independent-sample significance claim is made.
- Paired case differences require identical repeat sets, all complete and scored in both modes.
- The reporter can account only for supplied records; retain runner placeholders and the planned-record manifest.
- Smoke and validation cases were authored with implementation knowledge and are not independent holdouts.

## Observed model resources

| Group / mode / scale / model | Recorded invocations | Reported prompt / completion tokens | Reported usage.cost | Calls missing usage object | Complete IA scenario p50 / p95 ms |
|---|---:|---:|---:|---:|---:|
| validation / focus / 10000 / openai/gpt-6-luna | 64 | 292701 / 7282 | 0.0104899 | 0 | 14332.5 / 40337.6 |
| validation / retrieval / 10000 / openai/gpt-6-luna | 63 | 292928 / 6442 | 0.0102861 | 0 | 13351.4 / 25484.2 |

Token/cost sums cover only reported fields; per-field unavailable counts are in report.json. Missing usage is not zero. Provider usage.cost is separate from ledger reservations and is not an invoice guarantee. Scenario and model-invocation wall timings INCLUDE configured evaluation pacing; consult the run manifest for its interval. These local synthetic-scenario IA timings use mocked workers and are not production latency, completed user-task latency, or evidence of a speedup. Partial/error durations are reported separately in JSON.
