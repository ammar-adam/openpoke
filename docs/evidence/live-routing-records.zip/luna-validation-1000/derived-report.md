# Routing challenge results

Candidate inclusion, dispatch identity, reviewed behavior, and publication content are separate measurements.

| Group / mode / scale / metadata | Complete | Not run | Incomplete | Operational error | Routing protocol / reviewed ASK or ANSWER | Unscored complete |
|---|---:|---:|---:|---:|---:|---:|
| validation / focus / 1000 / current_state / openai/gpt-6-luna | 42 | 0 | 0 | 0 | 33/42 | 0 |
| validation / legacy / 1000 / current_state / openai/gpt-6-luna | 42 | 0 | 0 | 0 | 27/42 | 0 |
| validation / retrieval / 1000 / current_state / openai/gpt-6-luna | 42 | 0 | 0 | 0 | 32/42 | 0 |

Repeats are listed by case in report.json. The attempt counts above are not independent case counts and do not imply a majority-vote product.

## Lookup and publication metadata

| Group / mode / scale / model | All targets initially present / observed | Correct automatic dispatch identities / observed | Matching publication source IDs / observed | Completed callbacks |
|---|---:|---:|---:|---:|
| validation / focus / 1000 / openai/gpt-6-luna | 26/27 | 25/30 | 20/21 | 21 |
| validation / legacy / 1000 / openai/gpt-6-luna | 27/27 | 28/30 | 0/0 | 21 |
| validation / retrieval / 1000 / openai/gpt-6-luna | 24/27 | 25/30 | 21/21 | 21 |

Source-ID agreement is metadata, not proof of correct displayed content. An unobserved or inapplicable metric stays 0/0, not perfect accuracy.

## Complete paired cases: routing protocol / reviewed ASK or ANSWER

- validation / 1000 / current_state: legacy minus focus: -0.143; 14 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- validation / 1000 / current_state: retrieval minus focus: -0.024; 14 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- validation / 1000 / current_state: retrieval minus legacy: +0.119; 14 complete scored cases, 0 excluded. This is descriptive, not statistical significance.

## Reviewed semantics and content

| Group / mode | Behavior reviewed / eligible | Publication reviewed / completed callbacks | Joint correct / evaluated | Structural joint failures | Joint reviewer labels: human / model-assisted |
|---|---:|---:|---:|---:|---:|
| validation / focus / 1000 / openai/gpt-6-luna | 38/42 | 12/21 | 26/32 | 0 | 0 / 32 |
| validation / legacy / 1000 / openai/gpt-6-luna | 36/42 | 13/21 | 21/32 | 4 | 0 / 32 |
| validation / retrieval / 1000 / openai/gpt-6-luna | 39/42 | 10/21 | 25/31 | 1 | 0 / 31 |

## Interpretation

- Candidate inclusion is not final worker selection or task completion.
- Operational errors, incomplete runs, and not-run records are shown separately; they have no quality score.
- Completed ASK/ANSWER responses need attributed review; an unexpected dispatch still fails.
- The routing protocol score includes matching worker dispatches, a finished IA loop, and no extra callback dispatch; it is broader than worker identity alone.
- Worker identity uses observed_dispatch_correct, with automatic_correct only as a compatibility fallback for old rows missing that field. Identity matching does not establish instruction fidelity or completed worker actions.
- Review metrics distinguish human from model-assisted judgments and retain unreviewed counts.
- Publication metrics use completed callbacks even if the later follow-up fails; joint scenario review requires the whole run to complete.
- Joint scenario review checks displayed content and response/instruction behavior; mocked workers cannot establish actual task completion.
- Response correctness reviews only the follow-up. A failed IA loop or an extra callback dispatch independently forces completed joint scenarios to fail, even when response and publication labels are true.
- Joint structural failures can be known before content review; unreviewed component counts remain separate and those failures are not presented as human judgments.
- Source-ID annotation agreement is metadata only, not proof that the right content was displayed.
- Repeated attempts remain grouped by case; no majority-vote policy or independent-sample significance claim is made.
- Paired case differences require identical repeat sets, all complete and scored in both modes.
- The reporter can account only for supplied records; retain runner placeholders and the planned-record manifest.
- Smoke and validation cases were authored with implementation knowledge and are not independent holdouts.

## Observed model resources

| Group / mode / scale / model | Recorded invocations | Reported prompt / completion tokens | Reported usage.cost | Calls missing usage object | Complete IA scenario p50 / p95 ms |
|---|---:|---:|---:|---:|---:|
| validation / focus / 1000 / openai/gpt-6-luna | 179 | 817914 / 18848 | 0.0277601 | 0 | 11814 / 24847.4 |
| validation / legacy / 1000 / openai/gpt-6-luna | 167 | 3.43927e+06 / 16549 | 0.117236 | 0 | 9742.78 / 22443.2 |
| validation / retrieval / 1000 / openai/gpt-6-luna | 191 | 873976 / 19645 | 0.0292827 | 0 | 12244.7 / 22587 |

Token/cost sums cover only reported fields; per-field unavailable counts are in report.json. Missing usage is not zero. Provider usage.cost is separate from ledger reservations and is not an invoice guarantee. Scenario and model-invocation wall timings INCLUDE configured evaluation pacing; consult the run manifest for its interval. These local synthetic-scenario IA timings use mocked workers and are not production latency, completed user-task latency, or evidence of a speedup. Partial/error durations are reported separately in JSON.
