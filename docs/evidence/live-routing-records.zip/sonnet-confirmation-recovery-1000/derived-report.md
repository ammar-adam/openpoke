# Routing challenge results

Candidate inclusion, dispatch identity, reviewed behavior, and publication content are separate measurements.

| Group / mode / scale / metadata | Complete | Not run | Incomplete | Operational error | Routing protocol / reviewed ASK or ANSWER | Unscored complete |
|---|---:|---:|---:|---:|---:|---:|
| smoke / focus / 1000 / current_state / anthropic/claude-sonnet-4.6 | 4 | 0 | 0 | 0 | 4/4 | 0 |
| smoke / legacy / 1000 / current_state / anthropic/claude-sonnet-4.6 | 4 | 0 | 0 | 0 | 3/4 | 0 |
| smoke / retrieval / 1000 / current_state / anthropic/claude-sonnet-4.6 | 4 | 0 | 0 | 0 | 4/4 | 0 |
| validation / focus / 1000 / current_state / anthropic/claude-sonnet-4.6 | 4 | 0 | 0 | 0 | 3/4 | 0 |
| validation / legacy / 1000 / current_state / anthropic/claude-sonnet-4.6 | 4 | 0 | 0 | 0 | 3/4 | 0 |
| validation / retrieval / 1000 / current_state / anthropic/claude-sonnet-4.6 | 4 | 0 | 0 | 0 | 3/4 | 0 |

Repeats are listed by case in report.json. The attempt counts above are not independent case counts and do not imply a majority-vote product.

## Lookup and publication metadata

| Group / mode / scale / model | All targets initially present / observed | Correct automatic dispatch identities / observed | Matching publication source IDs / observed | Completed callbacks |
|---|---:|---:|---:|---:|
| smoke / focus / 1000 / anthropic/claude-sonnet-4.6 | 1/1 | 2/2 | 1/1 | 1 |
| smoke / legacy / 1000 / anthropic/claude-sonnet-4.6 | 1/1 | 2/2 | 0/0 | 1 |
| smoke / retrieval / 1000 / anthropic/claude-sonnet-4.6 | 1/1 | 2/2 | 1/1 | 1 |
| validation / focus / 1000 / anthropic/claude-sonnet-4.6 | 3/3 | 2/3 | 2/2 | 2 |
| validation / legacy / 1000 / anthropic/claude-sonnet-4.6 | 3/3 | 3/3 | 0/0 | 2 |
| validation / retrieval / 1000 / anthropic/claude-sonnet-4.6 | 3/3 | 2/3 | 1/2 | 2 |

Source-ID agreement is metadata, not proof of correct displayed content. An unobserved or inapplicable metric stays 0/0, not perfect accuracy.

## Complete paired cases: routing protocol / reviewed ASK or ANSWER

- smoke / 1000 / current_state: legacy minus focus: -0.250; 4 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- smoke / 1000 / current_state: retrieval minus focus: +0.000; 4 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- smoke / 1000 / current_state: retrieval minus legacy: +0.250; 4 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- validation / 1000 / current_state: legacy minus focus: +0.000; 4 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- validation / 1000 / current_state: retrieval minus focus: +0.000; 4 complete scored cases, 0 excluded. This is descriptive, not statistical significance.
- validation / 1000 / current_state: retrieval minus legacy: +0.000; 4 complete scored cases, 0 excluded. This is descriptive, not statistical significance.

## Reviewed semantics and content

| Group / mode | Behavior reviewed / eligible | Publication reviewed / completed callbacks | Joint correct / evaluated | Structural joint failures | Joint reviewer labels: human / model-assisted |
|---|---:|---:|---:|---:|---:|
| smoke / focus / 1000 / anthropic/claude-sonnet-4.6 | 4/4 | 0/1 | 3/3 | 0 | 0 / 3 |
| smoke / legacy / 1000 / anthropic/claude-sonnet-4.6 | 4/4 | 0/1 | 2/3 | 0 | 0 / 3 |
| smoke / retrieval / 1000 / anthropic/claude-sonnet-4.6 | 4/4 | 0/1 | 3/3 | 0 | 0 / 3 |
| validation / focus / 1000 / anthropic/claude-sonnet-4.6 | 4/4 | 1/2 | 2/3 | 0 | 0 / 3 |
| validation / legacy / 1000 / anthropic/claude-sonnet-4.6 | 3/4 | 2/2 | 2/3 | 0 | 0 / 3 |
| validation / retrieval / 1000 / anthropic/claude-sonnet-4.6 | 4/4 | 1/2 | 1/3 | 0 | 0 / 3 |

## Interpretation

- Candidate inclusion is not final worker selection or task completion.
- Operational errors, incomplete runs, and not-run records are shown separately; they have no quality score.
- Completed ASK/ANSWER responses need attributed review; an unexpected dispatch still fails.
- The routing protocol score includes matching worker dispatches, a finished IA loop, and no extra callback dispatch; it is broader than worker identity alone.
- Worker identity uses observed_dispatch_correct, with automatic_correct only as a compatibility fallback for old rows missing that field. Identity matching does not establish instruction fidelity or completed worker actions.
- Review metrics distinguish human from model-assisted judgments and retain unreviewed counts.
- Publication metrics use completed callbacks even if the later follow-up fails; joint scenario review requires the whole run to complete.
- Joint scenario review checks displayed content and response/instruction behavior; mocked workers cannot establish actual task completion.
- Response correctness reviews only the follow-up. A failed IA loop or an extra callback dispatch independently forces completed joint scenarios to fail, even when response and publication labels are true.
- Joint structural failures can be known before content review; unreviewed component counts remain separate and those failures are not presented as human judgments.
- Source-ID annotation agreement is metadata only, not proof that the right content was displayed.
- Repeated attempts remain grouped by case; no majority-vote policy or independent-sample significance claim is made.
- Paired case differences require identical repeat sets, all complete and scored in both modes.
- The reporter can account only for supplied records; retain runner placeholders and the planned-record manifest.
- Smoke and validation cases were authored with implementation knowledge and are not independent holdouts.

## Observed model resources

| Group / mode / scale / model | Recorded invocations | Reported prompt / completion tokens | Reported usage.cost | Calls missing usage object | Complete IA scenario p50 / p95 ms |
|---|---:|---:|---:|---:|---:|
| smoke / focus / 1000 / anthropic/claude-sonnet-4.6 | 10 | 57688 / 685 | 0.183339 | 0 | 5089.14 / 17340.5 |
| smoke / legacy / 1000 / anthropic/claude-sonnet-4.6 | 12 | 298661 / 798 | 0.907953 | 0 | 7428.2 / 17820.6 |
| smoke / retrieval / 1000 / anthropic/claude-sonnet-4.6 | 10 | 57716 / 686 | 0.183438 | 0 | 5050.25 / 45053.5 |
| validation / focus / 1000 / anthropic/claude-sonnet-4.6 | 17 | 105860 / 1555 | 0.340905 | 0 | 12729.7 / 18769.7 |
| validation / legacy / 1000 / anthropic/claude-sonnet-4.6 | 17 | 423268 / 1153 | 1.2871 | 0 | 12507 / 18140.2 |
| validation / retrieval / 1000 / anthropic/claude-sonnet-4.6 | 16 | 98938 / 1550 | 0.320064 | 0 | 11539.1 / 19531 |

Token/cost sums cover only reported fields; per-field unavailable counts are in report.json. Missing usage is not zero. Provider usage.cost is separate from ledger reservations and is not an invoice guarantee. Scenario and model-invocation wall timings INCLUDE configured evaluation pacing; consult the run manifest for its interval. These local synthetic-scenario IA timings use mocked workers and are not production latency, completed user-task latency, or evidence of a speedup. Partial/error durations are reported separately in JSON.
